﻿namespace ProyectoInventarioVF.Models
{
    public class estado
    {
        public int idestado { get; set; }
    }
}
