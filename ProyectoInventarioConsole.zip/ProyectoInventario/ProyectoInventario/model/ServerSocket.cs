﻿namespace ProyectoBodega.Modelo
{
    internal class ServerSocket
    {
        internal void Conectar() => throw new NotImplementedException();
    }
}