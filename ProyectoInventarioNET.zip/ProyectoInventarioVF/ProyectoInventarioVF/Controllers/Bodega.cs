﻿using Microsoft.AspNetCore.Mvc;

namespace ProyectoInventarioVF.Controllers
{
    public class Bodega : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
