﻿using Microsoft.AspNetCore.Mvc;

namespace ProyectoInventarioVF.Controllers
{
    public class ListarProductos : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
