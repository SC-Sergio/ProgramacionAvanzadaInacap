﻿using Microsoft.AspNetCore.Mvc;

namespace ProyectoInventarioVF.Controllers
{
    public class Retiro : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
