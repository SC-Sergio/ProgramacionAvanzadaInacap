﻿using Microsoft.AspNetCore.Mvc;

namespace ProyectoInventarioVF.Controllers
{
    public class Editar : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
