﻿using Microsoft.AspNetCore.Mvc;

namespace ProyectoInventarioVF.Controllers
{
    public class GestionarProductos : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
