﻿namespace ProyectoInventarioVF.Models
{
    public class administrador
    {
        public int AdministradorId { get; set; }
        public string? Administrador_run { get; set; }
        public string? Administrador_nombre { get; set; }
        public string? Administrador_password   { get; set; }
    }
}
