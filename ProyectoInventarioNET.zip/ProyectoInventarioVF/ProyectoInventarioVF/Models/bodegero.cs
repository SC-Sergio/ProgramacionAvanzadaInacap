﻿namespace ProyectoInventarioVF.Models
{
    public class bodegero
    {
        public int bodegeroid { get; set; }
        public string? bodegero_run { get; set; }
        public string? bodegero_nombre { get; set; }
        public string? bodegero_password { get; set; }
    }
}
