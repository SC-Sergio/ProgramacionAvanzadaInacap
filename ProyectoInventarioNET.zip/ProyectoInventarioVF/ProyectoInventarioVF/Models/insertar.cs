﻿using MySql.Data.MySqlClient;

namespace ProyectoInventarioVF.Models
{
    public class insertar
    {
        public void ctrinsertr(int cod, String nombre, String producto, int precio)
        {
            MySqlConnection conexionDB = Conexion.Connexion();
            String sql = "INSERT INTO bodegadatabase (id, nombre, producto, precio) VALUES ('" + cod + "', '" + nombre + "', '" + producto + "', '" + precio + "')";

            conexionDB.Open();

            try
            {
                MySqlCommand cmd = new(sql, conexionDB);
                cmd.ExecuteNonQuery();

            }
            catch (Exception exe)
            {
                Console.WriteLine("ERROR AL GUARDAR" + exe.Message);
            }
        }

        public class limpiar
        {



        }

    }
}