﻿namespace ProyectoInventarioVF.Models
{
    public class retiro
    {
        public int idretiro { get; set; }
        public int idproducto { get; set; }
    }
}
