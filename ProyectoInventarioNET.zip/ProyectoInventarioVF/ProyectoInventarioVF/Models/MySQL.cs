﻿namespace MysqlProject.Models
{
    public class administrador
    {
        public int AdministradorId { get; set; }
        public string? Administrador_run { get; set; }
        public string? Administrador_nombre { get; set; }
        public string? Administrador_password { get; set; }
    }

    public class administradorContext : DbContext
    {
        private DbSet<Administrador>? administrador;

        public DbSet<Administrador>? GetAdministrador()
        {
            return administrador;
        }

        public void SetAdministrador(DbSet<Administrador>? value)
        {
            administrador = value;
        }

        public class Administrador
        {
        }
    }

    public class DbContext
    {
    }

    public class DbSet<T>
    {
    }
}
