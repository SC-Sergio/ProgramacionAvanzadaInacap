﻿namespace ProyectoInventarioVF.Models
{
    public class login
    {
        public int bodegeroid { get; set; }
        public int adminid { get; set; }
        public string? bodegero_nombre { get; set; }
        public string? admin_nombre { get; set; }
        public string? bodegero_password { get; set; }
        public string? admin_password { get; set; }
    }
}
