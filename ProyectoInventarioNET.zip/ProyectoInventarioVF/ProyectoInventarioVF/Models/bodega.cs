﻿namespace ProyectoInventarioVF.Models
{
    public class bodega
    {
        public int bodegaid { get; set; }
        public string? bodegero_run { get; set; }
    }
}
