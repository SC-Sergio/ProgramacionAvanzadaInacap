﻿namespace ProyectoInventarioVF.Models
{
    public class producto
    {
        public int productoid  { get; set; }

    }
}
