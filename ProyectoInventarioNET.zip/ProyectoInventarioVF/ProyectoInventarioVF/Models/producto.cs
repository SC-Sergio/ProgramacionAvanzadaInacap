﻿namespace ProyectoInventarioVF.Models
{
    public class Producto
    {
        int id;
        String nombre;
        String descripcion;
        int precio;

        public Producto()
        {
        }

        public Producto(int id, string nombre, string descripcion, int precio, int stock)
        {
            this.id = id;
            this.nombre = nombre;
            this.descripcion = descripcion;
            this.precio = precio;
        }

        public int Id { get => id; set => id = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Descripcion { get => descripcion; set => descripcion = value; }
        public int Precio { get => precio; set => precio = value; }
    }
}