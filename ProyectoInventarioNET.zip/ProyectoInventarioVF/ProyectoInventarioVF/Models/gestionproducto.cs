﻿using MySql.Data.MySqlClient;
using ProyectoInventarioVF.Models;

namespace ProyectoInventarioVF.Models
{
    internal class gestionproducto
    {
        public List<object> consulta(String dato)
        {
            MySqlDataReader reader;
            List<object> lista = new List<object>();
            string sql;

            if (dato == null)
            {
                sql = "SELECT idproducto, nombre_producto, descripcion_producto, precio_producto FROM producto ORDER BY nombre ASC";
            }
            else
            {
                sql = "SELECT idproducto, nombre_producto, descripcion_producto, precio_producto FROM producto WHERE id LIKE '%" + dato + "%' OR nombre LIKE '%" + dato + "%' OR descripcion LIKE '%" + dato + "%' OR precio LIKE '%" + dato + "%' ORDER BY nombre ASC";
            }
            try
            {
                MySqlConnection conexionDB = Conexion.Connexion();
                conexionDB.Open();
                MySqlCommand comando = new MySqlCommand(sql, conexionDB);
                reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    Producto _pro = new Producto();
                    _pro.Id = int.Parse(reader.GetString(0));
                    //_producto.Codigo = reader[1].ToString();
                    _pro.Nombre = reader[1].ToString();
                    _pro.Descripcion = reader[2].ToString();
                    _pro.Precio = int.Parse(reader.GetString(3));
                    //_producto.Cantidad = int.Parse(reader.GetString(5));

                    lista.Add(_pro);

                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
            return lista;
        }
    }
}